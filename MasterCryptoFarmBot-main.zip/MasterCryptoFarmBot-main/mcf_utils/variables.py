# Developed by: MasterkinG32
# Date: 2024
# Github: https://github.com/masterking32
# Telegram: https://t.me/MasterCryptoFarmBot


APP_VERSION = "1.6.0"
GITHUB_REPOSITORY = "masterking32/MasterCryptoFarmBot"
